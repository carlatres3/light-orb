# Crystal Controls · Clear · v1 (free)

Buttons, a switch, a field and a slider in glass. A highlight follows the pointer; presses give like glass on a spring.
Every control has default, hover, focus, pressed, selected, disabled and loading states.

## What is in this folder

| File | What it is |
|---|---|
| `crystal-controls-clear.html` | Clear: Thick clear glass with a bright lower rim, for light pages. |
| `LICENCE.txt` | Your licence |

The .html file is complete on its own: no framework, no WebGL, no other files. Open it in a browser to try it.

## Put it in your page

Open `crystal-controls-clear.html` and copy:

1. the `:root { --cc-… }` variables and the rest of the `<style>`,
2. the controls you need from the markup (each one is a normal `<button>`, `<input>` or `role="switch"` button),
3. the `<script>` (pointer light and slider spring; the controls work without it, only less alive).

Use the same classes on your own buttons and fields: `cc-glass` plus the control class you see in the file.

## States

- **Disabled:** the standard `disabled` attribute.
- **Loading:** `aria-busy="true"` on a button.
- **Selected / on:** `aria-pressed="true"` or `aria-checked="true"`.
- **Focus:** a visible ring for keyboard users on every control.

## Other materials

The other versions are on https://thelightorb.com (launch prices, included in the Lifetime Pass).

## Good to know

On touch screens the highlight gathers where the finger presses and follows it while it moves.

Questions: hello@thelightorb.com — reply from Carla.

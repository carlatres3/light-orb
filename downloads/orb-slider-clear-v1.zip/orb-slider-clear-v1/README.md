# Orb Slider · Clear · v1 (free)

A slide-to-confirm control: a glass capsule whose thumb is a small orb with its own slow inner light.
Let go and a spring carries it home, or to the end to confirm.

## What is in this folder

| File | What it is |
|---|---|
| `orb-slider-clear.html` | Clear: Thick clear glass with a bright lower rim, for light pages. |
| `examples/OrbSlider.jsx` | A React / Next.js wrapper |
| `LICENCE.txt` | Your licence |

The .html file is complete on its own: no framework, no WebGL, no other files. Open it in a browser to try it.

## Put it in your page

Open `orb-slider-clear.html` and copy three parts into your page:

1. the `:root { --cc-… }` variables and the rest of the `<style>`,
2. the slider markup (`.cc-slide`),
3. the `<script>`.

Change the label text in the markup, and the colours with the `--cc-*` variables.

## Listen for the confirm

When the orb reaches the end, the slider sends a `confirm` event:

```js
document.querySelector('.cc-slide').addEventListener('confirm', () => {
  // go to the next page, send the form…
});
```

## Other materials

The other versions are on https://thelightorb.com (launch prices, included in the Lifetime Pass).

## Keyboard and access

Arrow keys move it, Enter and End confirm, Home returns it. It has `role="slider"` and a visible focus ring,
and it respects "reduce motion".

## Good to know

A slide is slower than a click: use it where the pause is the point (enter, book, send, unlock), not for everyday buttons.

Questions: hello@thelightorb.com — reply from Carla.

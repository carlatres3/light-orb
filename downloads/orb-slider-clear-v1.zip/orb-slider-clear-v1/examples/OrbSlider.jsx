// Orb Slider as a React component. It shows one material's file in an isolated frame
// and reports the confirm event. Copy the orb-slider-*.html files to /public/orb-slider/.
'use client';
import { useEffect, useRef } from 'react';

export default function OrbSlider({ material = 'clear', onConfirm, width = 360, height = 120 }) {
  const frame = useRef(null);
  useEffect(() => {
    const doc = () => frame.current?.contentDocument;
    const listen = () => doc()?.addEventListener('confirm', () => onConfirm?.(), { capture: true });
    const f = frame.current; f?.addEventListener('load', listen); listen();
    return () => f?.removeEventListener('load', listen);
  }, [onConfirm]);
  return <iframe ref={frame} title="Slide to confirm" src={`/orb-slider/orb-slider-${material}.html`}
    style={{ width, height, border: 0, background: 'transparent' }} />;
}

# The Orb · Clear · v1 (free)

A real-time 3D sphere for your website, drawn live in the browser (not a video). This free package is the Clear (Original) version.
Drag to turn it, tap to stir what is inside. Respects "reduce motion".

## What is in this folder

| File | What it is |
|---|---|
| `orb.js` | The Orb: one self-contained ES module (Three.js included) |
| `examples/hero.html` | A hero section with the Orb beside a headline |
| `examples/LightOrb.jsx` | A React / Next.js component |
| `stills/` | A still image of Clear, for browsers without WebGL 2 |
| `LICENCE.txt`, `THREE-LICENSE.txt` | Your licence, and the Three.js (MIT) licence |

## Try it

ES modules do not load from `file://`. In this folder run one of:

```
npx serve .
python3 -m http.server 8000
```

then open http://localhost:8000/examples/hero.html (or the address it prints).

## Put it in your page

1. Copy `orb.js` (and `stills/` if you want the fallback) into your site.
2. Add a box where the Orb should be. It fills the box; give it a size.
3. Load the script once per page.

```html
<div data-light-orb data-variant="clear" style="width:360px;height:360px">
  <img data-light-orb-fallback src="stills/clear.jpg" alt="" style="width:100%;height:100%;object-fit:contain">
</div>
<script type="module" src="/orb.js"></script>
```

The `<img data-light-orb-fallback>` is optional: visitors without WebGL 2 see it; everyone else sees the live Orb.

### From JavaScript

```js
import { mountOrb } from './orb.js';
const orb = mountOrb(document.querySelector('#hero-orb'), { variant: 'clear' });
orb.stir();      // a small push to what is inside
orb.dispose();   // remove it (for single-page apps)
```

## Other versions

The other versions are on https://thelightorb.com (launch prices, included in the Lifetime Pass).

## Good to know

- Needs WebGL 2: current Chrome, Safari, Edge and Firefox.
- A 3D scene uses more battery than an image: one Orb per page is the intended use.
- The Orb picks up the background colour of its box (or the nearest coloured parent).
- Size: about 170 KB compressed.

Questions: hello@thelightorb.com — reply from Carla.

// The Orb as a React component (React 18+, Next.js App Router: add "use client").
// Copy orb.js into your project (for example /public/orb/orb.js or src/vendor/orb.js).
'use client';
import { useEffect, useRef } from 'react';

export default function LightOrb({ variant = 'clear', size = 320, still, className, style }) {
  const host = useRef(null);
  useEffect(() => {
    let orb = null, gone = false;
    const gl = (() => { try { return !!document.createElement('canvas').getContext('webgl2'); } catch { return false; } })();
    if (!gl) return;   // no WebGL 2: the still image stays
    // Adjust this path to where you put orb.js.
    import(/* webpackIgnore: true */ '/orb/orb.js').then(({ mountOrb }) => {
      if (gone || !host.current) return;
      host.current.querySelector('[data-light-orb-fallback]')?.setAttribute('hidden', '');
      orb = mountOrb(host.current, { variant });
    });
    return () => { gone = true; orb?.dispose(); };
  }, [variant]);
  return (
    <div ref={host} className={className} style={{ width: size, height: size, ...style }}>
      {still && <img data-light-orb-fallback src={still} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />}
    </div>
  );
}
